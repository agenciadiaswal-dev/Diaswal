import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import { Activity, AlarmClock, Apple, ArrowRight, Check, CheckCircle2, Flame, Heart, Home, LogOut, MessageCircle, Plus, Send, ShieldCheck, Sparkles, Target, Wallet, Waves, X } from 'lucide-react'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'
import { hasSupabaseConfig, supabase } from './supabase'
import Landing from './Landing'

type Tab = 'routine' | 'meals' | 'money' | 'friend'
type Alarm = { id: string; title: string; time: string; category: string; done: boolean; procrastinated: boolean }
type Expense = { id: string; title: string; category: string; amount: number }
const initialAlarms: Alarm[] = [
  { id: 'a1', title: 'Beber água', time: '08:00', category: 'Saúde', done: false, procrastinated: false },
  { id: 'a2', title: 'Planejar as 3 prioridades', time: '08:15', category: 'Produtividade', done: false, procrastinated: false },
  { id: 'a3', title: 'Movimentar o corpo', time: '18:00', category: 'Bem-estar', done: false, procrastinated: false }
]
const mealNames = ['Café da manhã', 'Almoço', 'Lanche da tarde', 'Jantar']
const categories = ['Compras', 'Fast Food', 'Investimentos', 'Contas Fixas', 'Lazer']
const palette = ['#f97316', '#fb7185', '#22c55e', '#60a5fa', '#a78bfa']

export default function App() {
  const [session, setSession] = useState<any>(null)
  const [showLanding, setShowLanding] = useState(true)
  const [authLoading, setAuthLoading] = useState(true)
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [authError, setAuthError] = useState('')
  const [tab, setTab] = useState<Tab>('routine')
  const [alarms, setAlarms] = useState<Alarm[]>(initialAlarms)
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [water, setWater] = useState(0)
  const [meals, setMeals] = useState<string[]>([])
  const [messages, setMessages] = useState([{ role: 'assistant', text: 'E aí, lenda da procrastinação. 😏 Bora organizar esse caos ou vai deixar pra amanhã também?' }])
  const [chatInput, setChatInput] = useState('')
  const [showAlarmForm, setShowAlarmForm] = useState(false)
  const [alarmTitle, setAlarmTitle] = useState('')
  const [alarmTime, setAlarmTime] = useState('09:00')
  const [alarmCategory, setAlarmCategory] = useState('Rotina')
  const [showExpenseForm, setShowExpenseForm] = useState(false)
  const [expenseTitle, setExpenseTitle] = useState('')
  const [expenseAmount, setExpenseAmount] = useState('')
  const [expenseCategory, setExpenseCategory] = useState('Fast Food')
  const [goal, setGoal] = useState(500)
  const [saved, setSaved] = useState(120)
  const [toast, setToast] = useState('')
  const [streak, setStreak] = useState(3)
  const xp = alarms.filter(a => a.done).length * 25
  const doneCount = alarms.filter(a => a.done).length
  const totalSpent = expenses.reduce((s, e) => s + e.amount, 0)
  const pieData = useMemo(() => categories.map(category => ({ name: category, value: expenses.filter(e => e.category === category).reduce((s, e) => s + e.amount, 0) })).filter(d => d.value > 0), [expenses])

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setAuthLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next))
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!session?.user?.id || !supabase) return
    const uid = session.user.id
    let cancelled = false
    async function load() {
      const [a, e, p] = await Promise.all([
        supabase!.from('alarms').select('*').eq('user_id', uid).order('time'),
        supabase!.from('expenses').select('*').eq('user_id', uid).order('created_at', { ascending: false }),
        supabase!.from('daily_progress').select('*').eq('user_id', uid).eq('day', new Date().toISOString().slice(0, 10)).maybeSingle()
      ])
      if (cancelled) return
      if (a.data?.length) setAlarms(a.data.map((x: any) => ({ id: x.id, title: x.title, time: x.time.slice(0,5), category: x.category, done: x.status === 'done', procrastinated: x.status === 'procrastinated' })))
      if (e.data) setExpenses(e.data.map((x: any) => ({ id: x.id, title: x.title, category: x.category, amount: Number(x.amount) })))
      if (p.data) { setWater(p.data.water_glasses ?? 0); setStreak(p.data.streak ?? 3); setSaved(Number(p.data.saved_amount ?? 120)); setGoal(Number(p.data.savings_goal ?? 500)) }
    }
    load()
    const channel = supabase.channel('diaswal-live-'+uid)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'alarms', filter: `user_id=eq.${uid}` }, () => load())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses', filter: `user_id=eq.${uid}` }, () => load())
      .subscribe()
    return () => { cancelled = true; supabase?.removeChannel(channel) }
  }, [session?.user?.id])

  async function authenticate(e: FormEvent) {
    e.preventDefault(); setAuthError('')
    if (!supabase) { setAuthError('Configure VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY no arquivo .env para ativar o login.'); return }
    const result = authMode === 'login'
      ? await supabase.auth.signInWithPassword({ email, password })
      : await supabase.auth.signUp({ email, password })
    if (result.error) setAuthError(result.error.message)
    else if (authMode === 'signup' && !result.data.session) setAuthError('Cadastro iniciado! Confira seu e-mail para confirmar a conta.')
  }
  async function persistProgress(next: { water_glasses?: number; streak?: number; saved_amount?: number; savings_goal?: number }) {
    if (!supabase || !session?.user?.id) return
    await supabase.from('daily_progress').upsert({ user_id: session.user.id, day: new Date().toISOString().slice(0, 10), ...next }, { onConflict: 'user_id,day' })
  }
  async function markAlarm(alarm: Alarm, status: 'done' | 'procrastinated') {
    const updated = alarms.map(a => a.id === alarm.id ? { ...a, done: status === 'done', procrastinated: status === 'procrastinated' } : a)
    setAlarms(updated)
    if (status === 'done') { setToast('BOA! +25 XP. Uma vitória de cada vez. 🎉'); setStreak(s => s + 1); window.setTimeout(() => setToast(''), 2600) }
    else { setToast('Flagrado na procrastinação. O Amigo IA já ficou sabendo. 😈'); setMessages(m => [...m, { role: 'assistant', text: `Anotado: você procrastinou "${alarm.title}". Quer que eu chame isso de estratégia ou de preguiça premium? 😂` }]); window.setTimeout(() => setToast(''), 3000) }
    if (supabase && session?.user?.id) {
      await supabase.from('alarms').update({ status, completed_at: status === 'done' ? new Date().toISOString() : null }).eq('id', alarm.id).eq('user_id', session.user.id)
      await persistProgress({ streak: status === 'done' ? streak + 1 : streak })
    }
  }
  async function addAlarm(e: FormEvent) {
    e.preventDefault(); if (!alarmTitle.trim()) return
    const draft = { id: crypto.randomUUID(), title: alarmTitle.trim(), time: alarmTime, category: alarmCategory, done: false, procrastinated: false }
    setAlarms(a => [...a, draft].sort((x,y) => x.time.localeCompare(y.time)))
    if (supabase && session?.user?.id) {
      const { data, error } = await supabase.from('alarms').insert({ user_id: session.user.id, title: draft.title, time: alarmTime, category: alarmCategory, status: 'pending' }).select().single()
      if (error) setToast('Não foi possível salvar no servidor. Confira a configuração.')
      else if (data) setAlarms(a => a.map(x => x.id === draft.id ? { ...x, id: data.id } : x))
    }
    setAlarmTitle(''); setShowAlarmForm(false)
  }
  async function addExpense(e: FormEvent) {
    e.preventDefault(); const amount = Number(expenseAmount.replace(',', '.'))
    if (!expenseTitle.trim() || !Number.isFinite(amount) || amount <= 0) return
    const draft = { id: crypto.randomUUID(), title: expenseTitle.trim(), category: expenseCategory, amount }
    setExpenses(es => [draft, ...es])
    if (supabase && session?.user?.id) {
      const { data, error } = await supabase.from('expenses').insert({ user_id: session.user.id, title: draft.title, category: draft.category, amount }).select().single()
      if (error) setToast('Não foi possível salvar a despesa no servidor.')
      else if (data) setExpenses(es => es.map(x => x.id === draft.id ? { ...x, id: data.id } : x))
    }
    if (expenseCategory === 'Fast Food' && amount >= 40) setMessages(m => [...m, { role: 'assistant', text: `R$ ${amount.toFixed(2)} em Fast Food?! 🍔 O dono já devia te mandar cartão fidelidade e participação nos lucros. Respira antes do próximo pedido!` }])
    setExpenseTitle(''); setExpenseAmount(''); setShowExpenseForm(false)
  }
  async function changeWater(n: number) { const next = Math.max(0, Math.min(8, n)); setWater(next); await persistProgress({ water_glasses: next }) }
  async function sendChat(e: FormEvent) {
    e.preventDefault(); const text = chatInput.trim(); if (!text) return
    setMessages(m => [...m, { role: 'user', text }]); setChatInput('')
    const procrastinated = alarms.filter(a => a.procrastinated).length
    const fastFood = expenses.filter(x => x.category === 'Fast Food').reduce((s,x) => s+x.amount,0)
    const lower = text.toLowerCase()
    let reply = 'Tô ouvindo! Agora vamos transformar essa conversa em uma ação pequena e real. Qual é o primeiro passo que você consegue fazer em 2 minutos? 😎'
    if (lower.includes('pregui') || lower.includes('motiv') || lower.includes('socorro')) reply = 'LEVANTA, LENDA! 😂 Seu futuro eu mandou avisar que não vai se construir deitado. Faz só 2 minutos da tarefa. Depois você negocia com a preguiça — e provavelmente ganha.'
    else if (lower.includes('dinheiro') || lower.includes('gasto') || lower.includes('fast')) reply = `Seu registro mostra R$ ${fastFood.toFixed(2)} em Fast Food e ${totalSpent.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})} em gastos cadastrados. A carteira não é um buffet livre, meu consagrado. 💸`
    else if (lower.includes('procrast')) reply = `Tem ${procrastinated} tarefa(s) marcada(s) como procrastinada(s). Eu não julgo... tá, julgo um pouquinho. 😂 Escolhe uma e faz por 2 minutos.`
    setTimeout(() => setMessages(m => [...m, { role: 'assistant', text: reply }]), 350)
  }

  if (authLoading) return <div className="auth-screen"><div className="brand-mark"><Activity /></div><p>Preparando seu espaço...</p></div>
  if (!session && showLanding) return <Landing onStart={() => setShowLanding(false)} />
  if (!session) return <div className="auth-screen"><div className="auth-card"><div className="brand-lockup"><div className="brand-mark"><Activity /></div><div><h1>Diaswal</h1><p>Menos desculpas. Mais evolução.</p></div></div><h2>{authMode === 'login' ? 'Bem-vindo de volta' : 'Comece sua evolução'}</h2><p className="muted">Entre para acessar sua rotina, metas e progresso.</p><form onSubmit={authenticate} className="stack"><label>E-mail<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="voce@email.com"/></label><label>Senha<input type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres"/></label>{authError && <p className="error">{authError}</p>}<button className="primary wide" type="submit">{authMode === 'login' ? 'Entrar' : 'Criar minha conta'} <ArrowRight size={17}/></button></form><p className="switch-auth">{authMode === 'login' ? 'Ainda não tem conta?' : 'Já tem uma conta?'} <button className="link-button" onClick={()=>{setAuthMode(authMode==='login'?'signup':'login');setAuthError('')}}>{authMode === 'login' ? 'Cadastre-se' : 'Fazer login'}</button></p>{!hasSupabaseConfig && <div className="setup-note"><ShieldCheck size={17}/><span>Modo demonstração visual. Configure o Supabase para ativar autenticação e persistência.</span></div>}<p className="switch-auth"><button className="link-button" onClick={()=>setShowLanding(true)}>← Voltar à página inicial</button></p></div></div>

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand-lockup"><div className="brand-mark"><Activity /></div><div><h1>Diaswal</h1><p>DISCIPLINA EM JOGO</p></div></div><div className="side-user"><div className="avatar">{(session.user.email?.[0] || 'D').toUpperCase()}</div><div className="user-meta"><strong>Minha jornada</strong><span>{session.user.email}</span></div></div><nav className="side-nav">{navItems(tab,setTab)}</nav><div className="sidebar-bottom"><div className="upgrade-card"><Sparkles size={19}/><strong>Seu próximo nível começa hoje.</strong><p>Pequenos hábitos. Grandes mudanças.</p><span>DIASWAL PREMIUM</span></div><button className="ghost wide" onClick={()=>supabase?.auth.signOut()}><LogOut size={16}/> Sair da conta</button></div></aside>
    <main className="main-content"><header className="topbar"><div><p className="eyebrow">SEU PAINEL PESSOAL</p><h2>{tabTitle(tab)}</h2></div><div className="top-actions"><div className="date-chip">{new Date().toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'short'})}</div><div className="avatar small">{(session.user.email?.[0] || 'D').toUpperCase()}</div></div></header>
      {tab === 'routine' && <section className="page-content"><div className="welcome-row"><div><h3>Vamos fazer esse dia valer. <span>✦</span></h3><p>Consistência vence motivação. Bora marcar presença?</p></div><button className="primary" onClick={()=>setShowAlarmForm(true)}><Plus size={18}/> Novo alarme</button></div>
        <div className="stats-grid"><div className="stat-card streak-card"><div className="stat-icon orange"><Flame/></div><span className="stat-label">OFENSIVA ATUAL</span><strong>{streak} <small>dias</small></strong><p>Não deixe a chama apagar.</p></div><div className="stat-card"><div className="stat-icon purple"><Target/></div><span className="stat-label">XP ACUMULADO</span><strong>{xp} <small>XP</small></strong><div className="progress-track"><span style={{width:`${xp%100}%`}}/></div><p>Nível {Math.floor(xp/100)+1} · faltam {100-(xp%100)} XP</p></div><div className="stat-card"><div className="stat-icon green"><CheckCircle2/></div><span className="stat-label">PROGRESSO DE HOJE</span><strong>{alarms.length ? Math.round(doneCount/alarms.length*100) : 0}<small>%</small></strong><div className="progress-track green-track"><span style={{width:`${alarms.length ? doneCount/alarms.length*100 : 0}%`}}/></div><p>{doneCount} de {alarms.length} tarefas concluídas</p></div></div>
        <button className="crisis-banner" onClick={()=>{setTab('friend');setMessages(m=>[...m,{role:'assistant',text:'🚨 ALERTA DE PREGUIÇA! Seu sofá não vai colocar suas metas em prática. Levanta e faz só 2 minutinhos. Vai, protagonista de série que ainda não saiu do episódio 1! 😂'}])}}><div className="crisis-icon"><Heart/></div><div><strong>Socorro, tô com preguiça!</strong><span>Receba uma bronca motivacional do seu Amigo IA.</span></div><ArrowRight className="crisis-arrow"/></button>
        <div className="section-heading"><div><h3>Suas rotinas</h3><p>Um passo por vez. Você consegue.</p></div><span className="count-pill">{alarms.length} tarefas</span></div>
        <div className="alarm-list">{alarms.map(a=><article className={`alarm-card ${a.done?'is-done':''} ${a.procrastinated?'is-late':''}`} key={a.id}><div className="alarm-time">{a.time}</div><div className="alarm-line"/><div className="alarm-info"><strong>{a.title}</strong><span>{a.category}</span></div><div className="alarm-actions">{a.done?<span className="done-label"><Check size={15}/> Feito</span>:a.procrastinated?<span className="late-label">Procrastinei</span>:<><button className="complete-btn" onClick={()=>markAlarm(a,'done')}><Check size={15}/> Concluído</button><button className="procrastinate-btn" onClick={()=>markAlarm(a,'procrastinated')}>Procrastinei</button></>}</div></article>)}</div>
        {showAlarmForm && <div className="modal-backdrop"><form className="modal-card stack" onSubmit={addAlarm}><button type="button" className="modal-close" onClick={()=>setShowAlarmForm(false)}><X/></button><h3>Novo alarme</h3><label>Nome da rotina<input required value={alarmTitle} onChange={e=>setAlarmTitle(e.target.value)} placeholder="Ex.: Ler 10 páginas"/></label><div className="form-row"><label>Horário<input type="time" value={alarmTime} onChange={e=>setAlarmTime(e.target.value)}/></label><label>Categoria<select value={alarmCategory} onChange={e=>setAlarmCategory(e.target.value)}>{['Rotina','Saúde','Produtividade','Bem-estar','Estudos','Trabalho'].map(x=><option key={x}>{x}</option>)}</select></label></div><button className="primary wide">Salvar rotina</button></form></div>}
      </section>}
      {tab === 'meals' && <section className="page-content"><div className="welcome-row"><div><h3>Cuide de você por inteiro. <span>✦</span></h3><p>Alimentação organizada, dia mais leve.</p></div></div><div className="water-card"><div className="water-copy"><div className="stat-icon blue"><Waves/></div><div><span className="stat-label">HIDRATAÇÃO DIÁRIA</span><h3>{water} de 8 copos</h3><p>Um copo de cada vez — sem complicação.</p></div></div><div className="water-glasses">{Array.from({length:8},(_,i)=><button key={i} aria-label={`Marcar ${i+1} copos`} className={`glass ${i<water?'filled':''}`} onClick={()=>changeWater(i+1)}><Waves size={21}/></button>)}</div><div className="water-footer"><span>{Math.round(water/8*100)}% da meta diária</span><button className="link-button" onClick={()=>changeWater(0)}>Zerar</button></div><div className="progress-track blue-track"><span style={{width:`${water/8*100}%`}}/></div></div><div className="section-heading"><div><h3>Plano de refeições</h3><p>Marque o que você já consumiu hoje.</p></div><span className="count-pill">{meals.length}/4 feitas</span></div><div className="meal-grid">{mealNames.map((name,i)=><button key={name} className={`meal-card ${meals.includes(name)?'meal-done':''}`} onClick={()=>setMeals(m=>m.includes(name)?m.filter(x=>x!==name):[...m,name])}><div className={`meal-illustration meal-${i}`}><Apple/></div><div><span className="stat-label">REFEIÇÃO {i+1}</span><h3>{name}</h3><p>{meals.includes(name)?'Marcada como consumida':'Toque para marcar como feita'}</p></div><div className="meal-check">{meals.includes(name)&&<Check size={17}/>}</div></button>)}</div><div className="notice"><ShieldCheck size={18}/><span>Este organizador ajuda a acompanhar seus hábitos; não substitui orientação nutricional profissional.</span></div></section>}
      {tab === 'money' && <section className="page-content"><div className="welcome-row"><div><h3>Seu dinheiro merece um plano. <span>✦</span></h3><p>Enxergue seus gastos para decidir melhor.</p></div><button className="primary" onClick={()=>setShowExpenseForm(true)}><Plus size={18}/> Adicionar gasto</button></div><div className="money-summary"><div className="money-total"><span className="stat-label">GASTOS REGISTRADOS</span><h3>{totalSpent.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</h3><p>Com base nos lançamentos cadastrados.</p></div><div className="money-highlight"><div className="stat-icon orange"><Wallet/></div><div><span className="stat-label">FAST FOOD</span><strong>{expenses.filter(e=>e.category==='Fast Food').reduce((s,e)=>s+e.amount,0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</strong><p>Seus lanches estão no radar 👀</p></div></div></div><div className="finance-grid"><div className="panel"><div className="section-heading compact"><div><h3>Para onde vai seu dinheiro?</h3><p>Distribuição por categoria</p></div></div>{pieData.length?<><div className="chart-wrap"><ResponsiveContainer width="100%" height="220"><PieChart><Pie data={pieData} dataKey="value" nameKey="name" innerRadius={58} outerRadius={85} paddingAngle={4}>{pieData.map((entry,i)=><Cell key={entry.name} fill={palette[categories.indexOf(entry.name)%palette.length]}/>)}</Pie><Tooltip formatter={(v:any)=>Number(v).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}/></PieChart></ResponsiveContainer></div><div className="legend">{pieData.map(d=><div key={d.name}><span><i style={{background:palette[categories.indexOf(d.name)%palette.length]}}/>{d.name}</span><strong>{d.value.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</strong></div>)}</div></>:<div className="empty-state"><Wallet size={28}/><p>Adicione seu primeiro gasto para visualizar o gráfico.</p></div>}</div><div className="panel"><div className="section-heading compact"><div><h3>Meta de economia</h3><p>Pequenos depósitos, grandes objetivos.</p></div><Target size={20}/></div><div className="goal-amount"><span>Meta</span><strong>{goal.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</strong></div><input className="goal-input" type="number" min="1" value={goal} onChange={e=>{const n=Number(e.target.value);setGoal(n);persistProgress({savings_goal:n})}}/><div className="goal-amount"><span>Já economizado</span><strong className="green-text">{saved.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</strong></div><input className="goal-input" type="number" min="0" value={saved} onChange={e=>{const n=Number(e.target.value);setSaved(n);persistProgress({saved_amount:n})}}/><div className="progress-track green-track goal-progress"><span style={{width:`${Math.min(100,goal>0?saved/goal*100:0)}%`}}/></div><div className="goal-bottom"><strong>{Math.round(Math.min(100,goal>0?saved/goal*100:0))}%</strong><span>da meta alcançada</span></div><p className="muted small-text">Defina sua meta e atualize o valor guardado para acompanhar o progresso.</p></div></div><div className="panel expenses-panel"><div className="section-heading compact"><div><h3>Últimos lançamentos</h3><p>Suas despesas cadastradas</p></div></div>{expenses.length?expenses.map(e=><div className="expense-row" key={e.id}><div className="expense-icon"><Wallet size={17}/></div><div className="expense-name"><strong>{e.title}</strong><span>{e.category}</span></div><strong className={e.category==='Fast Food'?'orange-text':''}>− {e.amount.toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</strong></div>):<div className="empty-state"><p>Nenhum gasto cadastrado ainda.</p></div>}</div>{showExpenseForm&&<div className="modal-backdrop"><form className="modal-card stack" onSubmit={addExpense}><button type="button" className="modal-close" onClick={()=>setShowExpenseForm(false)}><X/></button><h3>Novo gasto</h3><label>Descrição<input required value={expenseTitle} onChange={e=>setExpenseTitle(e.target.value)} placeholder="Ex.: almoço"/></label><label>Valor (R$)<input required type="number" min="0.01" step="0.01" value={expenseAmount} onChange={e=>setExpenseAmount(e.target.value)} placeholder="0,00"/></label><label>Categoria<select value={expenseCategory} onChange={e=>setExpenseCategory(e.target.value)}>{categories.map(x=><option key={x}>{x}</option>)}</select></label><button className="primary wide">Salvar gasto</button></form></div>}</section>}
      {tab === 'friend' && <section className="page-content friend-page"><div className="friend-hero"><div className="friend-avatar"><MessageCircle/></div><div><span className="stat-label">SEU PARCEIRO DE RESPONSABILIDADE</span><h3>Amigo IA <span>✦</span></h3><p>Broncas com carinho. Sarcasmo com propósito.</p></div><span className="online-dot">● Online</span></div><div className="friend-context"><Sparkles size={18}/><div><strong>Ele acompanha seu progresso</strong><p>{alarms.filter(a=>a.procrastinated).length} tarefas procrastinadas · {expenses.filter(e=>e.category==='Fast Food').reduce((s,e)=>s+e.amount,0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})} em Fast Food registrado</p></div></div><div className="chat-window"><div className="chat-date">HOJE · SUA CONVERSA</div>{messages.map((m,i)=><div key={i} className={`chat-message ${m.role==='user'?'user-message':''}`}><div className="chat-bubble">{m.text}</div></div>)}</div><div className="suggestions"><button onClick={()=>setChatInput('Socorro, tô com preguiça!')}>😴 Tô com preguiça</button><button onClick={()=>setChatInput('Me dá uma bronca sobre meus gastos')}>💸 Meus gastos</button><button onClick={()=>setChatInput('Como paro de procrastinar?')}>🎯 Preciso de foco</button></div><form className="chat-compose" onSubmit={sendChat}><input value={chatInput} onChange={e=>setChatInput(e.target.value)} placeholder="Fala aí, o que tá pegando?"/><button className="primary send-button" aria-label="Enviar mensagem"><Send size={18}/></button></form><p className="chat-disclaimer">Amigo IA em modo inicial: respostas baseadas em regras locais. Conecte um provedor de IA no servidor para conversas generativas reais.</p></section>}
      {toast&&<div className="toast"><Sparkles size={18}/>{toast}</div>}
    </main>
    <nav className="mobile-nav">{navItems(tab,setTab)}</nav>
  </div>
}
function tabTitle(tab: Tab) { return ({routine:'Rotina e alarmes',meals:'Refeições',money:'Finanças',friend:'Amigo IA'})[tab] }
function navItems(tab: Tab, setTab: (t:Tab)=>void) {
  const items: {id:Tab; label:string; icon:any}[] = [{id:'routine',label:'Rotina',icon:Home},{id:'meals',label:'Refeições',icon:Apple},{id:'money',label:'Finanças',icon:Wallet},{id:'friend',label:'Amigo IA',icon:MessageCircle}]
  return items.map(item=>{const Icon=item.icon;return <button key={item.id} className={`nav-item ${tab===item.id?'active':''}`} onClick={()=>setTab(item.id)}><Icon size={19}/><span>{item.label}</span></button>})
}