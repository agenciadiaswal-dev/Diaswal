import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.agenciadiaswal.app',
  appName: 'Diaswal',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: { androidScheme: 'https' }
}

export default config
