-- Diaswal: initial schema. Execute no SQL Editor do seu projeto Supabase.
-- Todas as tabelas privadas usam RLS e vinculam registros ao usuário autenticado.
create extension if not exists pgcrypto;

create table if not exists public.alarms (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  time time not null,
  category text not null default 'Rotina',
  status text not null default 'pending' check (status in ('pending','done','procrastinated')),
  completed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  category text not null check (category in ('Compras','Fast Food','Investimentos','Contas Fixas','Lazer')),
  amount numeric(12,2) not null check (amount > 0),
  created_at timestamptz not null default now()
);

create table if not exists public.daily_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null default current_date,
  water_glasses integer not null default 0 check (water_glasses between 0 and 8),
  streak integer not null default 0 check (streak >= 0),
  saved_amount numeric(12,2) not null default 120 check (saved_amount >= 0),
  savings_goal numeric(12,2) not null default 500 check (savings_goal > 0),
  xp integer not null default 0 check (xp >= 0),
  updated_at timestamptz not null default now(),
  unique(user_id, day)
);

create table if not exists public.meals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  meal_date date not null default current_date,
  meal_type text not null check (meal_type in ('Café da manhã','Almoço','Lanche da tarde','Jantar')),
  description text not null,
  consumed boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) between 1 and 5000),
  created_at timestamptz not null default now()
);

alter table public.alarms enable row level security;
alter table public.expenses enable row level security;
alter table public.daily_progress enable row level security;
alter table public.meals enable row level security;
alter table public.chat_messages enable row level security;

create policy "Users manage own alarms" on public.alarms for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own expenses" on public.expenses for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own progress" on public.daily_progress for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own meals" on public.meals for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own chat messages" on public.chat_messages for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Habilita eventos realtime para tabelas acompanhadas pelo app.
alter publication supabase_realtime add table public.alarms;
alter publication supabase_realtime add table public.expenses;
alter publication supabase_realtime add table public.daily_progress;
alter publication supabase_realtime add table public.meals;
alter publication supabase_realtime add table public.chat_messages;
