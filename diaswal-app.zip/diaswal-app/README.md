# Diaswal — PWA e aplicativo Android/iOS

Projeto inicial em React + TypeScript + Vite, PWA e integração inicial com Supabase.

## Requisitos locais

- Node.js 20+ e npm
- Projeto Supabase para autenticação/dados
- Android: Android Studio e Android SDK
- iOS: macOS com Xcode e CocoaPods (a compilação iOS não é suportada diretamente em Windows/Android)

## Rodar a aplicação web

```bash
npm install
cp .env.example .env
# Edite .env com VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY
npm run dev
```

Build web: `npm run build`; preview: `npm run preview`.

## Preparar os projetos nativos

Depois de instalar dependências: 

```bash
npx cap add android
# No macOS, também execute:
npx cap add ios
npm run cap:sync
npm run cap:android
# No macOS:
npm run cap:ios
```

O Android Studio gera APK/AAB. Para iOS, abra o projeto no Xcode, configure assinatura/certificados e distribua via TestFlight/App Store Connect. Publicação nas lojas exige contas de desenvolvedor e configurações adicionais; ainda não há APK/IPA pré-compilado neste pacote.

## Publicar o PWA

Crie um repositório GitHub e importe-o no Vercel (ou outro host HTTPS) com build command `npm run build` e output `dist`. Configure as variáveis de ambiente no host: `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`. Depois de publicar, Android pode instalar pelo menu do navegador; iPhone pode usar Safari → Compartilhar → Adicionar à Tela de Início.

## Supabase

1. Crie um projeto no Supabase.
2. Configure `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` localmente e no host.
3. Execute `supabase/migrations/0001_initial_schema.sql` no SQL Editor.
4. Configure URLs de redirecionamento em Authentication → URL Configuration.
5. Nunca exponha a chave `service_role` no frontend. Teste as políticas RLS antes de aceitar usuários.

## Estado do produto

Este pacote é uma base de desenvolvimento, não um produto de produção concluído. O chat IA usa respostas de demonstração; o checkout de assinatura mensal ainda precisa de integração com um provedor de pagamento e webhook seguro. Parte das interações (refeições, água, chat, XP/ofensiva e metas) ainda precisa persistência completa no Supabase. Notificações de alarme não são alarmes garantidos em segundo plano. Faça testes de segurança, acessibilidade, privacidade e build antes do lançamento.
